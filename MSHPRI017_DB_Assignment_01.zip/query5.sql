SELECT country
FROM offices
WHERE state IS NULL;