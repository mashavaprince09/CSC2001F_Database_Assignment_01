SELECT ROUND( MAX(buyPrice*1.7),2)  AS top
FROM products;