SELECT ROUND(AVG(amount),2) AS mean, ROUND(SUM(amount),2) AS total
FROM payments;