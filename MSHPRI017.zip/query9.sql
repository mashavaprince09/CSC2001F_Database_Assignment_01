SELECT COUNT(DISTINCT productVendor) AS numVendors
FROM products;