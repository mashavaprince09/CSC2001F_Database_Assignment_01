SELECT *
FROM productlines
LIMIT 1;